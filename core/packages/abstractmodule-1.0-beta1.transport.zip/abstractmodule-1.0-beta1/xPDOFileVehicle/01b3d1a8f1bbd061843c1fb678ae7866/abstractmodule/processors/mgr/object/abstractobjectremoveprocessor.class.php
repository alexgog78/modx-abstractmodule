<?php

abstract class abstractObjectRemoveProcessor extends modObjectRemoveProcessor
{
}
