<?php

abstract class abstractObjectGetProcessor extends modObjectGetProcessor
{
}
