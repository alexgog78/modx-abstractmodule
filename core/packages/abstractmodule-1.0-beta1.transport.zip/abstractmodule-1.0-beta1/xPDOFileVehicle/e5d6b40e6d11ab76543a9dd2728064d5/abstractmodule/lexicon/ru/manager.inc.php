<?php

$prefix = '';

$_lang[$prefix . 'title.creating'] = 'Создаем: [[+record]]';
$_lang[$prefix . 'title.editing'] = 'Редактируем: [[+record]]';
$_lang[$prefix . 'controls.view'] = 'Просмотр';
$_lang[$prefix . 'controls.return'] = 'Назад';
$_lang[$prefix . 'controls.upload'] = 'Загрузить';
$_lang[$prefix . 'controls.source'] = 'Источник файлов';
