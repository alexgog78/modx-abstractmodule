<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '7444d85cdee021f97418f761baae1a2e',
      'native_key' => '7444d85cdee021f97418f761baae1a2e',
      'filename' => 'xPDOFileVehicle/01b3d1a8f1bbd061843c1fb678ae7866.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '41fc05954927bf2ed416a51a4897422c',
      'native_key' => '41fc05954927bf2ed416a51a4897422c',
      'filename' => 'xPDOFileVehicle/0dcfbe5f275274fab96d8e811b376a08.vehicle',
    ),
  ),
);