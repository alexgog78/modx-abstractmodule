<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for AbstractModule.
--------------------
¯\\_(ツ)_/¯
',
    'license' => '--------------------
AbstractModule
--------------------
Author: GrimWeb <a.goguev@alexgog.ru>
--------------------
',
    'readme' => 'AbstractModule
--------------------
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'aecd26626dd24eb2d42e2d2832368f07',
      'native_key' => 'aecd26626dd24eb2d42e2d2832368f07',
      'filename' => 'xPDOFileVehicle/e5d6b40e6d11ab76543a9dd2728064d5.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '03b170a596094575ea791c5d54b16fd6',
      'native_key' => '03b170a596094575ea791c5d54b16fd6',
      'filename' => 'xPDOFileVehicle/c21719ba7d837fa6fcfe5738a15ebf22.vehicle',
    ),
  ),
);