<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for abstractModule.
--------------------
¯\\_(ツ)_/¯
',
    'license' => '--------------------
abstractModule
--------------------
Author: GrimWeb <a.goguev@alexgog.ru>
--------------------
',
    'readme' => 'abstractModule
--------------------
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
',
    'requires' => 
    array (
      'php' => '>=7.0',
      'modx' => '>=2.4',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'ae6f3e8581e8f343b1a905000e7b82e3',
      'native_key' => 'ae6f3e8581e8f343b1a905000e7b82e3',
      'filename' => 'xPDOFileVehicle/934b752426c6a0d6768792ea0c83a660.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'b1a4bbe14c6ae7fce38b5be9e9274328',
      'native_key' => 'b1a4bbe14c6ae7fce38b5be9e9274328',
      'filename' => 'xPDOFileVehicle/8497ea8595bd444a0205b0ced12caba7.vehicle',
    ),
  ),
);