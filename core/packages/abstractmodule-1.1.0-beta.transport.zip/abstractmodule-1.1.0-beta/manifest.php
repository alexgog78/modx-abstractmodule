<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for abstractModule.
--------------------
¯\\_(ツ)_/¯
',
    'license' => '--------------------
abstractModule
--------------------
Author: GrimWeb <a.goguev@alexgog.ru>
--------------------
',
    'readme' => 'abstractModule
--------------------
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
',
    'requires' => 
    array (
      'php' => '>=7.0',
      'modx' => '>=2.4',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'c7eb9fba8019eb833dbb5b95e16d4ede',
      'native_key' => 'c7eb9fba8019eb833dbb5b95e16d4ede',
      'filename' => 'xPDOFileVehicle/d7caa5a5969371cb42913d094f84ae9b.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'd15f685e210daf6495d9dbe033e4a364',
      'native_key' => 'd15f685e210daf6495d9dbe033e4a364',
      'filename' => 'xPDOFileVehicle/323d2615d103b55b1ef5154c421b3a9b.vehicle',
    ),
  ),
);