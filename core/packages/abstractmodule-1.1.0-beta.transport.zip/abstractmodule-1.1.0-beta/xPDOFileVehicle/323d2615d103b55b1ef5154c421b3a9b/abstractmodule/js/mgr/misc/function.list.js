'use strict';

abstractModule.function = {

};
