<?php

require_once __DIR__ . '/default.class.php';

abstract class abstractModuleMgrCreateController extends abstractModuleMgrDefaultController
{

}
