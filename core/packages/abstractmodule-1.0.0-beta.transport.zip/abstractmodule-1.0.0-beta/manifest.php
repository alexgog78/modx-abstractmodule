<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for AbstractModule.
--------------------
¯\\_(ツ)_/¯
',
    'license' => '--------------------
AbstractModule
--------------------
Author: GrimWeb <a.goguev@alexgog.ru>
--------------------
',
    'readme' => 'AbstractModule
--------------------
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '2cc59801ebed45a65cfc15a968fa7a1f',
      'native_key' => '2cc59801ebed45a65cfc15a968fa7a1f',
      'filename' => 'xPDOFileVehicle/70411baf067176c3f002939cddf0ae64.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'c6754874c0b5f91d616e9acc8e28bccb',
      'native_key' => 'c6754874c0b5f91d616e9acc8e28bccb',
      'filename' => 'xPDOFileVehicle/4a9624aa9fb03f7ba14309ba72ba0809.vehicle',
    ),
  ),
);