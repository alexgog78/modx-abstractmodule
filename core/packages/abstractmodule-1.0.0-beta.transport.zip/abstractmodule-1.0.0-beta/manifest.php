<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for AbstractModule.
--------------------
¯\\_(ツ)_/¯
',
    'license' => '--------------------
AbstractModule
--------------------
Author: GrimWeb <a.goguev@alexgog.ru>
--------------------
',
    'readme' => 'AbstractModule
--------------------
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'cd6343495cf355bb261026851a5f7273',
      'native_key' => 'cd6343495cf355bb261026851a5f7273',
      'filename' => 'xPDOFileVehicle/1ef47c2e0451fda4e4dfcaada9278e36.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '9e10593d912dfe1da9be8d693e583666',
      'native_key' => '9e10593d912dfe1da9be8d693e583666',
      'filename' => 'xPDOFileVehicle/1e159bc710a5b1a5aeb79dac1d04ad9b.vehicle',
    ),
  ),
);