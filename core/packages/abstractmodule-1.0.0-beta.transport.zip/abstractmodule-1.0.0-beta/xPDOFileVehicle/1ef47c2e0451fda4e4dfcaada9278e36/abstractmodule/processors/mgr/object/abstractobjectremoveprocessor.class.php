<?php

abstract class AbstractObjectRemoveProcessor extends modObjectRemoveProcessor
{
}
