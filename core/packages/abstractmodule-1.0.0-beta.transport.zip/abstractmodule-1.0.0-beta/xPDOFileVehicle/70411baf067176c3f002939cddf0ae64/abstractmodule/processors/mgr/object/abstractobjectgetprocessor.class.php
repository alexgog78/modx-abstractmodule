<?php

abstract class AbstractObjectGetProcessor extends modObjectGetProcessor
{
}
