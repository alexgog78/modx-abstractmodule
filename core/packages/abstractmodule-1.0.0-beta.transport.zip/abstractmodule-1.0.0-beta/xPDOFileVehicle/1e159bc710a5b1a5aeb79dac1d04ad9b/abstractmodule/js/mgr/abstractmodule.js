'use strict';

var abstractModule = {
    page: {},
    window: {},
    grid: {},
    localGrid: {},
    tree: {},
    panel: {},
    formPanel: {},
    tabs: {},
    combo: {},
    notice: {},
    config: {},
    renderer: {},
    function: {},
};
